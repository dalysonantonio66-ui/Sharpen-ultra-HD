# AIM ASSIST PRO — SHARPEN EDITION

Perfil inicial: **Ultra HD / Android potente**

O app inclui controles locais para Nitidez, Contraste, Saturação e Brilho, além de salvar as preferências no aparelho. Os números são sugestões de perfil e não alteram a renderização de outros aplicativos.

## Gerar APK pelo GitHub Actions
1. Crie um repositório no GitHub.
2. Envie o conteúdo desta pasta para a raiz do repositório, incluindo `.github/workflows/build-apk.yml`.
3. Abra a aba **Actions** e execute **Build AIM ASSIST PRO SHARPEN APK** (ou aguarde o build automático após push).
4. Baixe o artefato `AIM-ASSIST-PRO-SHARPEN-APK` da execução concluída.
5. Extraia o artefato e instale `app-debug.apk`.

## Requisitos
- Android Studio/Gradle para compilação local, ou GitHub Actions para compilação na nuvem.
- JDK 17 e Android SDK Platform 35.

## Limitações técnicas
Um aplicativo Android comum não pode aplicar um filtro de nitidez diretamente sobre a imagem de outro app/jogo. Este projeto não usa overlay, captura de tela contínua, root, injeção, leitura de memória ou modificação do Blood Strike. Para nitidez real durante o jogo, use as opções gráficas do jogo ou os controles de imagem oferecidos pelo fabricante do aparelho, se houver.
